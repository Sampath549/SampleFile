﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class LoginController : ApiController
    {
        [Route("api/Login/CheckLogin")]
        public async Task<IHttpActionResult> AssignRole(UserData model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //var result = await UserManager.AddToRoleAsync(model.UserId, model.Role);
            var result = "";
            return Ok(result);
        }
    }
}
