﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using WebApp.Models;

namespace WebApp.Helper
{
    public static class OAuthHelper
    {
        public static string AccessToken = GetOAuthToken();

        private static string GetOAuthToken()
        {
            const string _ClientKey = "abc";
            const string _ClientSecret = "ddddddddd";
            string _Username = "dr@gmail.com"; //"dr@gmail.com";
            string _Password = "dr@gmail.com"; //"Admin@12345";
            string _Url = GlobalVariables.Instance.ApiUrl;

            var session = HttpContext.Current.Session;
            AccessTokenModel token = null;
            if (session["Token"] != null)
            {
                token = session["Token"] as AccessTokenModel;
                if (token.ExpiresOn != null)
                {
                    if (DateTime.Compare(DateTime.Now, token.ExpiresOn.Value) > 0)
                        token = null;
                }
                else token = null;
            }
            if (token != null) return token.AccessToken;

            using (var client = new HttpClient())
            {
                // Get the bearer token.

                client.BaseAddress = new Uri(_Url);
                client.DefaultRequestHeaders.Clear();
                //client.DefaultRequestHeaders.Add("Authorization", authorization);

                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("username", _Username),
                    new KeyValuePair<string, string>("password", _Password),
                    new KeyValuePair<string, string>("client_id", _ClientKey),
                    new KeyValuePair<string, string>("client_secret", _ClientSecret),
                    new KeyValuePair<string, string>("grant_type", "password"),
                });
                //////////////////////////New



                var result = client.PostAsync("token", content).Result.Content.ReadAsStringAsync().Result;
                if (!string.IsNullOrEmpty(result))
                {
                    token = JsonConvert.DeserializeObject<AccessTokenModel>(result);
                    session["Token"] = token;
                }
                return token.AccessToken;
                /////////////////
            }

        }
    }
}