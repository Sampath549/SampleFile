﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace WebApp.Helper
{
    public sealed class GlobalVariables
    {
        private static readonly GlobalVariables instance = new GlobalVariables();
        public readonly string ApiUrl;
        public string ClientId;
        public string Secret;

        static GlobalVariables()
        {
        }

        private GlobalVariables()
        {
            ApiUrl = WebConfigurationManager.AppSettings["ConfigApiUrl"];
            ClientId = WebConfigurationManager.AppSettings["ConfigClientId"];
            Secret = WebConfigurationManager.AppSettings["ConfigSecret"];
        }

        public static GlobalVariables Instance
        {
            get
            {
                return instance;
            }
        }
    }
}