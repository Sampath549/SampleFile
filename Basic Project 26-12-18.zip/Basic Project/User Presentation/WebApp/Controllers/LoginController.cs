﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp.App_Start;
using WebApp.Helper;
using WebApp.Models.SharedEntities;

namespace WebApp.Controllers
{
    public class LoginController : Controller
    {
        SE_Users Users;
        public ActionResult LoginPage()
        {
            return View();
        }

        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CheckAuthentication(string _User, string _Password)
        {
            Users = new SE_Users();
            try
            {
                Users.EmailId = _User;
                Users.Password = _Password;

                var _JsonString = JsonConvert.SerializeObject(Users);
                var response = ApiHelper.GetData("api/Login/CheckLogin", _JsonString);
                dynamic resultAdd = JsonConvert.DeserializeObject(response);

                return Json(new { Users }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Users }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult RegistrationPage()
        {
            return View();
        }
        public ActionResult ForgotPasswordPage()
        {
            return View();
        }

    }
}