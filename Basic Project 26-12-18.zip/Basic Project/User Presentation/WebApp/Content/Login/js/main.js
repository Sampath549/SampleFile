(function ($) {
    "use strict";
    /*==================================================================
    [ Focus input ]*/
    $('.input100').each(function () {
        $(this).on('blur', function () {
            if ($(this).val().trim() != "") {
                $(this).addClass('has-val');
            }
            else {
                $(this).removeClass('has-val');
            }
        })
    })

    function TokenHeaderValue() {
        var cookieToken, formToken;
        //AntiForgery.GetTokens(null, out cookieToken, out formToken);
        return cookieToken + ":" + formToken;
    }

    /*==================================================================
    [ Validate Login ]*/
    var input = $('.validate-input .input100');
    $('#btnLogin').click(function () {
        var check = true;

        for (var i = 0; i < input.length; i++) {
            if (validate(input[i]) == false) {
                showValidate(input[i]);
                check = false;
            }
        }
        if (check) {
            $.ajax({
                type: "POST",
                url: "/Login/CheckAuthentication",
                data: { _User: $('#email').val(), _Password: $('#pass').val() },
                dataType: "json",
                cache: false,
                headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                success: function (response) {
                    console.log(response);
                    return true;
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    alert(xhr.responseText);
                    return false;
                }
            });
        }
        else
            return check;
    });

    //$('.validate-form-login').on('submit', function () {
    //    var check = true;

    //    for (var i = 0; i < input.length; i++) {
    //        if (validate(input[i]) == false) {
    //            showValidate(input[i]);
    //            check = false;
    //        }
    //    }

    //    if (check) {
    //        alert(12)
    //        window.location.href = 'https://www.w3schools.com/jsref/event_onsubmit.asp'
    //    }
    //    return check;
    //});

    $('.validate-form-login .input100').each(function () {
        $(this).focus(function () {
            hideValidate(this);
        });
    });

    /*==================================================================
    [ Validate Registration ]*/
    var input = $('.validate-input .input100');
    $('#btnRegistration').click(function () {
        var check = true;

        for (var i = 0; i < input.length; i++) {
            if (validate(input[i]) == false) {
                showValidate(input[i]);
                check = false;
            }
        }

        if (check) {
            window.location.href = '/Login/CheckAuthentication'
        }
        return check;
    });

    $('.validate-form-reg .input100').each(function () {
        $(this).focus(function () {
            hideValidate(this);
        });
    });

    /*==================================================================
    [ Validate ForgotPwd ]*/
    var input = $('.validate-input .input100');
    $('#btnForgotPwd').click(function () {
        var check = true;

        for (var i = 0; i < input.length; i++) {
            if (validate(input[i]) == false) {
                showValidate(input[i]);
                check = false;
            }
        }

        if (check) {
            window.location.href = '/Login/CheckAuthentication'
        }
        return check;
    });

    $('.validate-form-forgotpwd .input100').each(function () {
        $(this).focus(function () {
            hideValidate(this);
        });
    });

    /*==================================================================
    [ Comman Validation ]*/
    function validate(input) {
        if ($(input).attr('type') == 'email' || $(input).attr('name') == 'email') {
            if ($(input).val().trim().match(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/) == null) {
                if ($("#email").val() != '')
                    $("#EmailId").attr("data-validate", "Enter a Valid Email");
                return false;
            }
        }
        else {
            if ($(input).val().trim() == '') {
                return false;
            }
        }

        if ($(input).attr('name') == 'mobile') {
            if ($(input).val().trim().match(/^[0-9-+()]*$/) == null) {
                if ($("#mobile").val() != '')
                    $("#MobileNum").attr("data-validate", "Enter only Numbers");
                return false;
            }
        }
        else {
            if ($(input).val().trim() == '') {
                return false;
            }
        }
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }

    /*==================================================================
    [ Show pass ]*/
    var showPass = 0;
    $('.btn-show-pass').on('click', function () {
        if (showPass == 0) {
            $(this).next('input').attr('type', 'text');
            $(this).addClass('active');
            showPass = 1;
        }
        else {
            $(this).next('input').attr('type', 'password');
            $(this).removeClass('active');
            showPass = 0;
        }

    });

})(jQuery);