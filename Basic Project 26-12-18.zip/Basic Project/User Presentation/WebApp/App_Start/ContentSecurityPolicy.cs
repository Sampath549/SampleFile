﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace WebApp.App_Start
{
    public class ContentSecurityPolicy : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            string _ClientURL = ConfigurationManager.AppSettings["ConfigClientUrl"].ToString();

            var _Response = filterContext.HttpContext.Response;
            var _ProjectUrls = string.Join(
                                           " ",
                                           " " + _ClientURL + " "
                                          );
            var _FontUrls = string.Join(
                                        " ",
                                        " https://maps.googleapis.com/ "
                                       );

            StringBuilder sb = new StringBuilder();

            sb.Append("default-src  'self' " + _ProjectUrls + " ;");
            sb.Append("style-src 'self' 'unsafe-inline' " + _ProjectUrls + " ;");
            sb.Append("script-src 'self' 'unsafe-inline' " + _ProjectUrls + " ;");
            sb.Append("img-src 'self' 'unsafe-inline' " + _ProjectUrls + " ;");
            sb.Append("font-src 'self' 'unsafe-inline' " + _FontUrls + " ;");
            _Response.AddHeader("Content-Security-Policy", sb.ToString());

            base.OnActionExecuting(filterContext);
        }
    }
}