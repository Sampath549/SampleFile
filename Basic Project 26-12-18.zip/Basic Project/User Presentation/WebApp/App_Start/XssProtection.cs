﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.App_Start
{
    public class XssProtection : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var _Response = filterContext.HttpContext.Response;
            _Response.AddHeader("X-XSS-Protection", "1; mode=block");

            if (ConfigurationManager.AppSettings["WorkingEnvironment"].ToString() == "Live")
                _Response.AddHeader("Strict-Transport-Security", "max-age=11536000; includeSubDomains");
        }
    }
}