﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Models.SharedEntities
{
    public partial class SE_Users
    {
        public int Status { get; set; }
        public int UserId { get; set; }
        public string Name { get; set; }
        public string DBToken { get; set; }
    }
}