IF OBJECT_ID (N'[Ref_Roles]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Roles]

CREATE TABLE [Ref_Roles]
(
[RoleId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_RefRoleId PRIMARY KEY ([RoleId]),
CONSTRAINT UC_RefRoleCode UNIQUE ([Code])
)

INSERT [Ref_Roles] ([Code], [Description]) VALUES ('DEV', 'Developer')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('SA', 'Super Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('ADM', 'Admin')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('USR', 'User')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('BUS', 'Business')
INSERT [Ref_Roles] ([Code], [Description]) VALUES ('COMM', 'Community')

SELECT * FROM [Ref_Roles]  

----- END -----

IF OBJECT_ID (N'[tbl_Users]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Users]

CREATE TABLE [tbl_Users]
(
[UserId]				INT					NOT NULL IDENTITY(1,1),
[PersonalKey]			VARCHAR(800)		NOT NULL,
[FirstName]				VARCHAR(800)		NOT NULL,
[LastName]				VARCHAR(800)		NOT NULL,
[RoleId]				INT					NOT NULL,
[Password]				VARCHAR(800)		NOT NULL,
[SaltKey]				VARCHAR(800)		NOT NULL,
[EmailId]				VARCHAR(800)		NOT NULL,
[EmailCheck]				VARCHAR(800)		NOT NULL,
[Mobile]				VARCHAR(800)		NOT NULL,
[MobileCheck] 				VARCHAR(800)		NOT NULL,
[Photo]					VARCHAR(800)		NULL,
[Gender]				CHAR(1)				NULL,
[IsFirstTimeLogin]		BIT					DEFAULT 1,
[FailedLoginAttempts]	INT					DEFAULT 0,
[DisableAccountTime]		DATETIME			NULL,
[IsActive]				BIT					DEFAULT 1,
[CreatedBy]				INT					NOT NULL,
[CreatedDate]			DATETIME			DEFAULT GETDATE(),
[ModifiedBy]			INT					NULL,
[ModifiedDate]			DATETIME			NULL,
CONSTRAINT PK_tblUserId PRIMARY KEY ([UserId]),
CONSTRAINT FK_tblURole FOREIGN KEY ([CreatedBy]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT FK_tblUCreated FOREIGN KEY ([CreatedBy]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_tblUModified FOREIGN KEY ([ModifiedBy]) REFERENCES [tbl_Users]([UserId])
)

INSERT [tbl_Users]
(
[PersonalKey],
[FirstName], 
[LastName], 
[RoleId],
[Password], 
[SaltKey],
[EmailId],
[EmailCheck],
[Mobile],
[MobileCheck],
[IsFirstTimeLogin],
[IsActive],
[CreatedBy],
[CreatedDate]
) 
VALUES 
(
'2W6ppjh+6bi2veYXNrz3LyQVLFaj+r7/9CBL2horM8MhYF/kvm5kmSZ0t//tAStkHf0IWR8cPYE8kvPO7Qmc7w==',
'AhU+KNMJioCmoJw2oT+65g2UG+mIbJUYX2v0/BCMP6c=', 
'bF3touMtIMA9H+OOVGFlNctvgi6FTNaZmF6GVQU8aw8=', 
1,
'tF2Qh8Rbhhx1jRqRRtR0fOVaeYG+iVT8MeExfeKpn9w=', 
'1X51Bf6FGv5ENt++VQRT/u9BTd5q9Wmvst9d/KZZ0RM=', 
'wHJuzGDS7F+tj6L1bEgk9ndvWaf9T9Ub7DOTvUUWfll/4fEFoDpYyV1hzLBhM61o', 
'Xk4Zw+C8PndeMJkBKVSVw5/gINK/7S+nubH4M5gQmeg=', 
'h1TIGpbN6h6XheJsxVtJyw72ufPQnyxjHGc3WbgA3os=',
'wWAOX1vUTy3SOlULE+99Bw==',
1,
1,
1,
GETDATE()
)

---- Actual Values
--FirstName - Sampath
--LastName - Bandari
--Email - sampath.bandari51@gmail.com
--Mobile - 8121839354
--Password - W#9cqh;B
--Salt - Gou[{Is&

SELECT * FROM [tbl_Users]

----- END -----

IF OBJECT_ID (N'[tbl_Audits]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Audits]

CREATE TABLE [tbl_Audits]
(
[UserId]			INT				NOT NULL,
[IPAddress]			VARCHAR(100)		NOT NULL,
[EntryType]			VARCHAR(10)		NOT NULL,
[EntryFrom]			VARCHAR(10)		NOT NULL,
[Browser]			VARCHAR(600)	NOT NULL,
[Resolution]		VARCHAR(50)		NOT NULL,
[Location]			VARCHAR(500)	NOT NULL,
[Latitude]			VARCHAR(50)		NOT NULL,
[Longitude]			VARCHAR(50)		NOT NULL,
[AccessTime]		DATETIME		NOT NULL,
[IsSuccess]			BIT				NOT NULL,
CONSTRAINT UC_ALUserATime UNIQUE ([UserId], [AccessTime]),
CONSTRAINT FK_ALUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_Audits]

----- END -----

IF OBJECT_ID (N'[tbl_UserSecurityQuestions]', N'U') IS NOT NULL 
   DROP TABLE [tbl_UserSecurityQuestions]

CREATE TABLE [tbl_UserSecurityQuestions]
(
[UserId]			INT				NOT NULL,
[SecurityQue]		VARCHAR(200)	NOT NULL,
[SecurityAns]		VARCHAR(200)	NULL,
CONSTRAINT UC_USQUserSecurity UNIQUE ([UserId], [SecurityQue]),
CONSTRAINT FK_USQUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_UserSecurityQuestions]  

----- END -----

IF OBJECT_ID (N'[Ref_Countries]', N'U') IS NOT NULL 
   DROP TABLE [Ref_Countries]

CREATE TABLE [Ref_Countries]
(
[CountryId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_CountryId PRIMARY KEY ([CountryId]),
CONSTRAINT UC_CountryCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_Countries] ([Code], [Description]) VALUES ('AUS', 'Austria')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('BEL', 'Belgium')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('BUL', 'Bulgaria')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('CRO', 'Croatia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('CYP', 'Cyprus')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('CZE', 'Czechia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('DEN', 'Denmark')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('EST', 'Estonia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('FIN', 'Finland')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('FRA', 'France')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GER', 'Germany')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('GRE', 'Greece')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('HUN', 'Hungary')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('IRE', 'Ireland')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('ITA', 'Italy')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('LAT', 'Latvia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('LIT', 'Lithuania')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('LUX', 'Luxembourg')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('MAL', 'Malta')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('NET', 'Netherlands')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('POL', 'Poland')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('POR', 'Portugal')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('ROM', 'Romania')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SLO', 'Slovakia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SLOV', 'Slovenia')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SPA', 'Spain')
INSERT [Ref_Countries] ([Code], [Description]) VALUES ('SWE', 'Sweden')

SELECT * FROM [Ref_Countries]  

----- END -----
IF OBJECT_ID (N'[Ref_States]', N'U') IS NOT NULL 
   DROP TABLE [Ref_States]

CREATE TABLE [Ref_States]
(
[StateId]		INT				NOT NULL IDENTITY(1,1),
[Code]			VARCHAR(5)		NOT NULL,
[Description]	VARCHAR(100)	NOT NULL,
[CountryId]		INT				NOT NULL,
[CreatedDate]	DATETIME		DEFAULT GETDATE(),
[ModifiedDate]	DATETIME		NULL,
CONSTRAINT PK_StateId PRIMARY KEY ([StateId]),
CONSTRAINT FK_CState FOREIGN KEY ([CountryId]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT UC_StateCodeDesc UNIQUE ([Code],[Description])
)

INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('BER', 'Berlin', 11)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('HAM', 'Hamburg', 11)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('SAA', 'Saarland', 11)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('WAR', 'Warsaw', 21)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('OPO', 'Opole', 21)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('MAS', 'Masovian', 21)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('BUD', 'Budapest', 13)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('FEJ', 'Fejer', 13)
INSERT [Ref_States] ([Code], [Description], [CountryId]) VALUES ('NOG', 'Nograd', 13)

SELECT * FROM [Ref_States]  

----- END -----

IF OBJECT_ID (N'[tbl_UserMapping]', N'U') IS NOT NULL 
   DROP TABLE [tbl_UserMapping]

CREATE TABLE [tbl_UserMapping]
(
[UserId]					INT				NOT NULL,
[IsPermanentAddress]		BIT				NULL,
[PermanentStreetAddress]	VARCHAR(MAX)	NULL,
[PermanentCity]				VARCHAR(800)	NULL,
[PermanentState]			INT				NULL,
[PermanentCountry]			INT				NULL,
[PermanentZipCode]			BIGINT			NULL,
[CurrentStreetAddress]		VARCHAR(MAX)	NULL,
[CurrentCity]				VARCHAR(800)	NULL,
[CurrentState]				INT				NULL,
[CurrentCountry]			INT				NULL,
[CurrentZipCode]			BIGINT			NULL,
CONSTRAINT FK_UMUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId]),
CONSTRAINT FK_UMPState FOREIGN KEY ([PermanentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMPCountry FOREIGN KEY ([PermanentCountry]) REFERENCES [Ref_Countries]([CountryId]),
CONSTRAINT FK_UMCState FOREIGN KEY ([CurrentState]) REFERENCES [Ref_States]([StateId]),
CONSTRAINT FK_UMCCountry FOREIGN KEY ([CurrentCountry]) REFERENCES [Ref_Countries]([CountryId])
)

SELECT * FROM [tbl_UserMapping]  

----- END -----

IF OBJECT_ID (N'[tbl_ResetPwdLog]', N'U') IS NOT NULL 
   DROP TABLE [tbl_ResetPwdLog]

CREATE TABLE [tbl_ResetPwdLog]
(
[ResetPwdLogId]		INT				NOT NULL IDENTITY(1,1),
[UserId]			INT				NOT NULL,
[GuidVal]			VARCHAR(800)	NOT NULL,
[IsReset]			BIT				NOT NULL,
[EntryDate]			DATETIME		NOT NULL
CONSTRAINT PK_ResetPwdLogId PRIMARY KEY ([ResetPwdLogId]),
CONSTRAINT FK_RPwdUser FOREIGN KEY ([UserId]) REFERENCES [tbl_Users]([UserId])
)

SELECT * FROM [tbl_ResetPwdLog]

----- END -----

IF OBJECT_ID (N'[tbl_Menus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_Menus]

CREATE TABLE [tbl_Menus]
(
[ParentId]		INT				NOT NULL IDENTITY(1,1),
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NULL,
[Action]		VARCHAR(50)		NULL,
[HavingChild]	BIT				NOT NULL,
[Order]			INT				NOT NULL,
[Icon]			VARCHAR(50)		NOT NULL,
CONSTRAINT PK_ParentId PRIMARY KEY ([ParentId]),
CONSTRAINT UC_PHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Dashboard', 'CPanel', 'Dashboard', 0, 1, 'fa fa-bookmark-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('All Users', NULL, NULL, 1, 2, 'fa fa-user-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Master Data', NULL, NULL, 1, 3, 'fa fa-star-o')
INSERT INTO [tbl_Menus] ([Header], [Controller], [Action], [HavingChild], [Order], [Icon]) VALUES ('Error Log', 'CPanel', 'ViewErrorLog', 0, 4, 'fa fa-exclamation-triangle')

SELECT * FROM [tbl_Menus]  

----- END -----

IF OBJECT_ID (N'[tbl_SubMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_SubMenus]

CREATE TABLE [tbl_SubMenus]
(
[ChildId]		INT 			NOT NULL IDENTITY(1,1),
[ParentId]		INT				NOT NULL,
[Header]		VARCHAR(50)		NOT NULL,
[Controller]	VARCHAR(50)		NOT NULL,
[Action]		VARCHAR(50)		NOT NULL,
[Order]			INT				NOT NULL,
CONSTRAINT PK_ChildId PRIMARY KEY ([ChildId]),
CONSTRAINT FK_SMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT UC_CHeaderControllerAction UNIQUE ([Header],[Controller],[Action])
)

INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Create', 'CPanel', 'CreateAllUsers', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (2, 'Details', 'CPanel', 'AllUserDetails', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Roles', 'CPanel', 'CreateRole', 1)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Menus', 'CPanel', 'CreateMenus', 2)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Sub Menus', 'CPanel', 'CreateSubMenus', 3)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Assigned Menus', 'CPanel', 'CreateAssignedMenus', 4)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'Countries', 'CPanel', 'CreateCountries', 5)
INSERT INTO [tbl_SubMenus] ([ParentId], [Header], [Controller], [Action], [Order]) VALUES (3, 'States', 'CPanel', 'CreateStates', 6)

SELECT * FROM [tbl_SubMenus]

----- END -----

IF OBJECT_ID (N'[tbl_AssignMenus]', N'U') IS NOT NULL 
   DROP TABLE [tbl_AssignMenus]

CREATE TABLE [tbl_AssignMenus]
(
[AssignMenuId]	INT 	NOT NULL IDENTITY(1,1),
[ParentId]		INT		NOT NULL,
[RoleId]		INT		NOT NULL,
CONSTRAINT PK_AssignMenuId PRIMARY KEY ([AssignMenuId]),
CONSTRAINT FK_AMenusParentId FOREIGN KEY ([ParentId]) REFERENCES [tbl_Menus]([ParentId]),
CONSTRAINT FK_AMenusRoleId FOREIGN KEY ([RoleId]) REFERENCES [Ref_Roles]([RoleId]),
CONSTRAINT UC_AMenusParentRole UNIQUE ([ParentId],[RoleId])
)

INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (1, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (2, 1)
INSERT INTO [tbl_AssignMenus] ([ParentId], [RoleId]) VALUES (3, 1)

SELECT * FROM [tbl_AssignMenus]

----- END -----
