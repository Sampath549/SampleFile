﻿using BootstrapEditor.Models;
using System.Web.Mvc;

namespace BootstrapEditor.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            HomeViewModel model = new HomeViewModel();
            return View();
        }

        [ValidateInput(false)]
        [HttpPost]
        public ActionResult Index(HomeViewModel model)
        {
            return View(model);
        }
    }
}