﻿
namespace BootstrapEditor.Models
{
    public class HomeViewModel
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}